/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ddf5b5d */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/q05/4.B/mikula/zamek/Zamek/zam.vhd";



static void work_a_1586608709_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(22, ng0);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4120);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(23, ng0);
    t4 = (t0 + 1352U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    if (t10 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 1192U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB11;

LAB13:
LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(24, ng0);
    t4 = (t0 + 4232);
    t11 = (t4 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)0;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(26, ng0);
    t2 = (t0 + 2152U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 4232);
    t8 = (t2 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t6;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

}

static void work_a_1586608709_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(34, ng0);
    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)4);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)5);
    if (t4 != 0)
        goto LAB5;

LAB6:    xsi_set_current_line(41, ng0);
    t1 = (t0 + 4296);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(42, ng0);
    t1 = (t0 + 4360);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB3:    t1 = (t0 + 4136);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(35, ng0);
    t1 = (t0 + 4296);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 4360);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(38, ng0);
    t1 = (t0 + 4296);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(39, ng0);
    t1 = (t0 + 4360);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

}

static void work_a_1586608709_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    static char *nl0[] = {&&LAB3, &&LAB4, &&LAB5, &&LAB6, &&LAB7, &&LAB8};

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4424);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 4152);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(52, ng0);
    t4 = (t0 + 1672U);
    t5 = *((char **)t4);
    t4 = (t0 + 6585);
    t8 = 1;
    if (4U == 4U)
        goto LAB13;

LAB14:    t8 = 0;

LAB15:    if (t8 != 0)
        goto LAB10;

LAB12:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6589);
    t3 = 1;
    if (4U == 4U)
        goto LAB21;

LAB22:    t3 = 0;

LAB23:    if (t3 != 0)
        goto LAB19;

LAB20:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 4424);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)5;
    xsi_driver_first_trans_fast(t1);

LAB11:    goto LAB2;

LAB4:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6593);
    t3 = 1;
    if (4U == 4U)
        goto LAB30;

LAB31:    t3 = 0;

LAB32:    if (t3 != 0)
        goto LAB27;

LAB29:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6597);
    t3 = 1;
    if (4U == 4U)
        goto LAB38;

LAB39:    t3 = 0;

LAB40:    if (t3 != 0)
        goto LAB36;

LAB37:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 4424);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)5;
    xsi_driver_first_trans_fast(t1);

LAB28:    goto LAB2;

LAB5:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6601);
    t3 = 1;
    if (4U == 4U)
        goto LAB47;

LAB48:    t3 = 0;

LAB49:    if (t3 != 0)
        goto LAB44;

LAB46:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6605);
    t3 = 1;
    if (4U == 4U)
        goto LAB55;

LAB56:    t3 = 0;

LAB57:    if (t3 != 0)
        goto LAB53;

LAB54:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 4424);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)5;
    xsi_driver_first_trans_fast(t1);

LAB45:    goto LAB2;

LAB6:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6609);
    t3 = 1;
    if (4U == 4U)
        goto LAB64;

LAB65:    t3 = 0;

LAB66:    if (t3 != 0)
        goto LAB61;

LAB63:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6613);
    t3 = 1;
    if (4U == 4U)
        goto LAB72;

LAB73:    t3 = 0;

LAB74:    if (t3 != 0)
        goto LAB70;

LAB71:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 4424);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)5;
    xsi_driver_first_trans_fast(t1);

LAB62:    goto LAB2;

LAB7:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6617);
    t3 = 1;
    if (4U == 4U)
        goto LAB81;

LAB82:    t3 = 0;

LAB83:    if (t3 != 0)
        goto LAB78;

LAB80:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 4424);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB79:    goto LAB2;

LAB8:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 6621);
    t3 = 1;
    if (4U == 4U)
        goto LAB90;

LAB91:    t3 = 0;

LAB92:    if (t3 != 0)
        goto LAB87;

LAB89:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4424);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB88:    goto LAB2;

LAB9:    xsi_set_current_line(96, ng0);
    goto LAB2;

LAB10:    xsi_set_current_line(53, ng0);
    t11 = (t0 + 4424);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)1;
    xsi_driver_first_trans_fast(t11);
    goto LAB11;

LAB13:    t9 = 0;

LAB16:    if (t9 < 4U)
        goto LAB17;
    else
        goto LAB15;

LAB17:    t7 = (t5 + t9);
    t10 = (t4 + t9);
    if (*((unsigned char *)t7) != *((unsigned char *)t10))
        goto LAB14;

LAB18:    t9 = (t9 + 1);
    goto LAB16;

LAB19:    xsi_set_current_line(55, ng0);
    t7 = (t0 + 1992U);
    t10 = *((char **)t7);
    t8 = *((unsigned char *)t10);
    t7 = (t0 + 4424);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t8;
    xsi_driver_first_trans_fast(t7);
    goto LAB11;

LAB21:    t9 = 0;

LAB24:    if (t9 < 4U)
        goto LAB25;
    else
        goto LAB23;

LAB25:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB22;

LAB26:    t9 = (t9 + 1);
    goto LAB24;

LAB27:    xsi_set_current_line(61, ng0);
    t7 = (t0 + 4424);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t7);
    goto LAB28;

LAB30:    t9 = 0;

LAB33:    if (t9 < 4U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB31;

LAB35:    t9 = (t9 + 1);
    goto LAB33;

LAB36:    xsi_set_current_line(63, ng0);
    t7 = (t0 + 1992U);
    t10 = *((char **)t7);
    t8 = *((unsigned char *)t10);
    t7 = (t0 + 4424);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t8;
    xsi_driver_first_trans_fast(t7);
    goto LAB28;

LAB38:    t9 = 0;

LAB41:    if (t9 < 4U)
        goto LAB42;
    else
        goto LAB40;

LAB42:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB39;

LAB43:    t9 = (t9 + 1);
    goto LAB41;

LAB44:    xsi_set_current_line(69, ng0);
    t7 = (t0 + 4424);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB45;

LAB47:    t9 = 0;

LAB50:    if (t9 < 4U)
        goto LAB51;
    else
        goto LAB49;

LAB51:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB48;

LAB52:    t9 = (t9 + 1);
    goto LAB50;

LAB53:    xsi_set_current_line(71, ng0);
    t7 = (t0 + 1992U);
    t10 = *((char **)t7);
    t8 = *((unsigned char *)t10);
    t7 = (t0 + 4424);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t8;
    xsi_driver_first_trans_fast(t7);
    goto LAB45;

LAB55:    t9 = 0;

LAB58:    if (t9 < 4U)
        goto LAB59;
    else
        goto LAB57;

LAB59:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB56;

LAB60:    t9 = (t9 + 1);
    goto LAB58;

LAB61:    xsi_set_current_line(77, ng0);
    t7 = (t0 + 4424);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)4;
    xsi_driver_first_trans_fast(t7);
    goto LAB62;

LAB64:    t9 = 0;

LAB67:    if (t9 < 4U)
        goto LAB68;
    else
        goto LAB66;

LAB68:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB65;

LAB69:    t9 = (t9 + 1);
    goto LAB67;

LAB70:    xsi_set_current_line(79, ng0);
    t7 = (t0 + 1992U);
    t10 = *((char **)t7);
    t8 = *((unsigned char *)t10);
    t7 = (t0 + 4424);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t8;
    xsi_driver_first_trans_fast(t7);
    goto LAB62;

LAB72:    t9 = 0;

LAB75:    if (t9 < 4U)
        goto LAB76;
    else
        goto LAB74;

LAB76:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB73;

LAB77:    t9 = (t9 + 1);
    goto LAB75;

LAB78:    xsi_set_current_line(85, ng0);
    t7 = (t0 + 1992U);
    t10 = *((char **)t7);
    t8 = *((unsigned char *)t10);
    t7 = (t0 + 4424);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t8;
    xsi_driver_first_trans_fast(t7);
    goto LAB79;

LAB81:    t9 = 0;

LAB84:    if (t9 < 4U)
        goto LAB85;
    else
        goto LAB83;

LAB85:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB82;

LAB86:    t9 = (t9 + 1);
    goto LAB84;

LAB87:    xsi_set_current_line(91, ng0);
    t7 = (t0 + 4424);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)5;
    xsi_driver_first_trans_fast(t7);
    goto LAB88;

LAB90:    t9 = 0;

LAB93:    if (t9 < 4U)
        goto LAB94;
    else
        goto LAB92;

LAB94:    t5 = (t2 + t9);
    t6 = (t1 + t9);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB91;

LAB95:    t9 = (t9 + 1);
    goto LAB93;

}


extern void work_a_1586608709_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1586608709_3212880686_p_0,(void *)work_a_1586608709_3212880686_p_1,(void *)work_a_1586608709_3212880686_p_2};
	xsi_register_didat("work_a_1586608709_3212880686", "isim/zam_sim_isim_beh.exe.sim/work/a_1586608709_3212880686.didat");
	xsi_register_executes(pe);
}
